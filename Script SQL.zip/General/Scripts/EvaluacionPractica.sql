create database notas;

use notas;

create table usuarios (
	id int primary key auto_increment,
	nombre varchar(20) not null,
	email varchar(20) not null
);

create table notas (
	id int primary key auto_increment,
	titulo varchar(100) not null,
	creacion date not null,
	modificacion date,
	descripcion varchar(600) not null
);

create table categorias (
	id int primary key auto_increment,
	nombre varchar(20) not null
);

create table categorias_notas (
	id int primary key auto_increment,
	categorias_id int not null,
	notas_id int
);

ALTER TABLE notas.notas ADD CONSTRAINT notas_FK FOREIGN KEY (id) REFERENCES notas.usuarios(id);

ALTER TABLE notas.categorias_notas ADD CONSTRAINT categorias_notas_FK FOREIGN KEY (categorias_id) REFERENCES notas.categorias(id);
ALTER TABLE notas.categorias_notas ADD CONSTRAINT categorias_notas_FK_1 FOREIGN KEY (notas_id) REFERENCES notas.notas(id);


INSERT INTO notas.usuarios (nombre,email)
	VALUES ('Camila Gaytan','cami@mail.com');
INSERT INTO notas.usuarios (nombre,email)
	VALUES ('Lionel Messi','messi@mail.com');
INSERT INTO notas.usuarios (nombre,email)
	VALUES ('Leo Ponzio','leo@mail.com');
INSERT INTO notas.usuarios (nombre,email)
	VALUES ('Enzo Perez','enzo@mail.com');
INSERT INTO notas.usuarios (nombre,email)
	VALUES ('Luciano De Cecco','lucho@mail.com');
INSERT INTO notas.usuarios (nombre,email)
	VALUES ('Indio Solari','indio@mail.com');
INSERT INTO notas.usuarios (nombre,email)
	VALUES ('Charly Garcia','charly@mail.com');
INSERT INTO notas.usuarios (nombre,email)
	VALUES ('Daddy Yankee','elrey@mail.com');
INSERT INTO notas.usuarios (nombre,email)
	VALUES ('Gonzalo Montiel','cache@mail.com');
INSERT INTO notas.usuarios (nombre,email)
	VALUES ('Marcelo Barovero','trapito@mail.com');


INSERT INTO notas.categorias (nombre)
	VALUES ('Musica');
INSERT INTO notas.categorias (nombre)
	VALUES ('Deporte');
INSERT INTO notas.categorias (nombre)
	VALUES ('Entretenimiento');
INSERT INTO notas.categorias (nombre)
	VALUES ('Economia');
INSERT INTO notas.categorias (nombre)
	VALUES ('Policial');
INSERT INTO notas.categorias (nombre)
	VALUES ('Politica');
INSERT INTO notas.categorias (nombre)
	VALUES ('Arte');
INSERT INTO notas.categorias (nombre)
	VALUES ('Ciencia');
INSERT INTO notas.categorias (nombre)
	VALUES ('Historia');
INSERT INTO notas.categorias (nombre)
	VALUES ('Geografia');


INSERT INTO notas.notas (titulo,creacion,descripcion)
	VALUES ('La Copa de la historia','2018-12-09','H�roes. Para la historia, para toda la vida. En Madrid, s�, in�dito. En la final m�s imporante de la historia del f�tbol argentino. Este River no necesita imperiosamente que Gallardo est� en el banco, este River sabe muy bien lo que tiene que hacer en la cancha. Dirija quien dirija desde el banco. Por eso se lo dio vuelta a Boca, por eso lo gan�, por eso lo cerr� con esa contra el Pity Mart�nez a los 120 minutos, definiendo con el arco libre y d�ndole el cachetazo final al rival de toda su vida. Y Copa, al Mundial de Clubes de Emiratos y clasificaci�n a la Libertadores 2019,.');
INSERT INTO notas.notas (titulo,creacion,modificacion,descripcion)
	VALUES ('La Renga revalid� credenciales como la banda m�s convocante del rock argentino','2022-04-24','2022-04-25','�Gracias por recibirnos, La Plata�. Con esas palabras Chizzo daba la bienvenida al primero de los tres shows que La Renga dar� en el Estadio �nico Diego Armando Maradona de esa ciudad. Una trilog�a que confirmar�, como si a esta altura fuera necesario, que el grupo de Mataderos es el m�s convocante del rock argentino. Despu�s del saludo, �A tu lado� fue el primer cl�sico que cort� con los dos estrenos que dieron comienzo al show: �Buena pipa� y �Parece un caso perdido�, ambos de Alejado de la red, su disco m�s reciente y la excusa para esta nueva gira.');
INSERT INTO notas.notas (titulo,creacion,modificacion,descripcion)
	VALUES ('Mart�n Fierro 2022: "Cien argentinos dicen" gan� como mejor programa de entretenimientos','2022-05-15','2022-05-16','El ciclo conducido por Dar�o Barassi se llev� la estatuilla como mejor programa de entretenimientos de 2021. Barassi agradeci� a la producci�n y se emocion� mencionando a su mujer y sus hijos.');
INSERT INTO notas.notas (titulo,creacion,descripcion)
	VALUES ('Argentina campe�n de la Copa Am�rica: un grito que tard� 28 a�os y que le sac� la espina a Messi','2021-07-10','Se termin� el maleficio. Luego de 28 a�os donde la gloria se escurri� m�s de una vez de entre la manos, la Selecci�n argentina volvi� a gritar campe�n tras vencer a Brasil en la final de la Copa Am�rica. Y si alguien se merec�a ese t�tulo tan esquivo era su capit�n Lionel Messi, quien por fin pude ser llevado en andas por sus compa�eros.');
INSERT INTO notas.notas (titulo,creacion,modificacion,descripcion)
	VALUES ('D�a de la Tierra: un bosque flotante en Venecia, creado por un argentino','2022-04-22','2022-04-25','M�s de medio siglo despu�s de que Nicol�s Garc�a Uriburu coloreara de verde el Gran Canal de Venecia, otro argentino presenta en las mismas aguas en bosque flotante, de 20 metros cuadrados, que tendr� su versi�n en el metaverso. Galla (A flote) se titula la creaci�n del artista neuquino Aaron Nachtailer presentada hasta hoy, D�a de la Tierra, en el marco de la 59� edici�n de la gran bienal.');
INSERT INTO notas.notas (titulo,creacion,modificacion,descripcion)
	VALUES ('Erupci�n del volc�n Villarrica','2015-03-04','2015-03-10','El volc�n chileno Villarrica, situado en la regi�n sure�a de la Araucan�a, ha entrado en erupci�n pasadas las 03.00 de la madrugada de este martes, por lo que las autoridades han decretado la alerta roja y han iniciado la evacuaci�n de las poblaciones aleda�as.');
INSERT INTO notas.notas (titulo,creacion,descripcion)
	VALUES ('Las plantas cultivadas en suelo lunar crecen con ra�ces atrofiadas y tallos y hojas m�s peque�os','2022-05-13','Durante las misiones Apolo (entre 1969 y 1972), los astronautas de la NASA se trajeron, entre rocas y arena (regolito), 382 kilogramos de Luna. Este material ha sido estudiado desde todos los �ngulos de la ciencia. En los a�os 70 espolvorearon varias plantas para ver que les pasaba. Un grupo de investigadores ha utilizado parte del polvo tra�do hace 50 a�os para cultivar plantas por primera vez en suelo lunar. Han comprobado que s�, que los vegetales germinan y crecen, pero lo hacen mucho peor que en el terrestre.');
INSERT INTO notas.notas (titulo,creacion,modificacion,descripcion)
	VALUES ('Horror en Maschwitz: Cruz� las v�as con auriculares puestos y la atropell� el tren','2019-10-09','2019-10-14','Una terrible fatalidad ocurri� este jueves a la ma�ana en Ingeniero Maschwitz, donde una estudiante universitaria de 19 a�os falleci� al cruzar distra�damente las v�as de la l�nea Mitre y ser atropellada por un tren que se dirig�a a la estaci�n de esa localidad.');
INSERT INTO notas.notas (titulo,creacion,modificacion,descripcion)
	VALUES ('Hernan Lacunza: �Vamos a mandar al Congreso �La Ley de Estad�stica��','2019-11-07','2019-11-10','Desde el Palacio de Hacienda, Lacunza asegur� que se va a mandar al Congreso un proyecto de ley tendiente a jerarquizar el INDEC: �Vamos a mandar en los pr�ximos d�as al Congreso uno de los proyectos de ley que entendemos que es un pilar de la Argentina que viene: �La Ley de Estad�stica�, que procura jerarquizar al Instituto, dotarlo de independencia y garantizar la calidad que todos queremos de las estad�sticas p�blicas. Ser� debatido de manera plural en el Congreso para tener una mejor ley y en beneficio de todos los argentinos�.');
INSERT INTO notas.notas (titulo,creacion,descripcion)
	VALUES ('Con m�s de 500 artistas y 100 actividades gratuitas, arranca la quinta Bienal de Arte Joven','2022-04-14','Bajo el lema "El h�bito de crear mundos", el pr�ximo mi�rcoles 20 de abril dar� comienzo en el Centro Cultural Recoleta la quinta edici�n de la Bienal de Arte Joven, que a lo largo de cinco jornadas marat�nicas ofrecer� espect�culos de m�sica, teatro, danza, cine, performance, muestras visuales, literatura, dise�o, DJs, y m�s de 100 actividades gratuitas en las que participar�n m�s de 500 artistas.');



INSERT INTO notas.categorias_notas (categorias_id,notas_id)
	VALUES (1,2);
INSERT INTO notas.categorias_notas (categorias_id,notas_id)
	VALUES (2,1);
INSERT INTO notas.categorias_notas (categorias_id,notas_id)
	VALUES (2,4);
INSERT INTO notas.categorias_notas (categorias_id,notas_id)
	VALUES (3,3);
INSERT INTO notas.categorias_notas (categorias_id,notas_id)
	VALUES (4,9);
INSERT INTO notas.categorias_notas (categorias_id,notas_id)
	VALUES (5,8);
INSERT INTO notas.categorias_notas (categorias_id)
	VALUES (6);
INSERT INTO notas.categorias_notas (categorias_id,notas_id)
	VALUES (7,5);
INSERT INTO notas.categorias_notas (categorias_id,notas_id)
	VALUES (7,10);
INSERT INTO notas.categorias_notas (categorias_id,notas_id)
	VALUES (8,7);
INSERT INTO notas.categorias_notas (categorias_id)
	VALUES (9);
INSERT INTO notas.categorias_notas (categorias_id,notas_id)
	VALUES (10,6);


